package com.example.hp.ss;

public class Contact {


     String username,password;


    public void setUserName(String username) {

        this.username=username;

    }

    public String getUsername() {
        return this.username;
    }

    public void setPassword(String password) {

        this.password=password;

    }

    public String getPassword() {
        return this.password;
    }
}
